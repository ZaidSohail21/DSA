//#include "MyLL.h"
//#include <iostream>
//int main() {
//	MyLL obj;
//	cout << "Delete at value between :" << obj.DeleteAtValue(1);
//	cout << endl;
//	obj.InsertAtTail(1);
//	cout << "Delete at value between :" << obj.DeleteAtValue(1);
//	cout << endl;
//	obj.InsertAtTail(2);
//	obj.InsertAtTail(3);
//	obj.InsertAtTail(4);
//	obj.InsertAtTail(5);
//	obj.InsertAtTail(6);
//	obj.InsertAtTail(7);
//	obj.InsertAtTail(8);
//
//	obj.display();
//	cout << endl;
//
//	obj.InsertAtHead(3);
//	obj.InsertAtHead(4);
//	obj.display();
//	cout << endl;
//	cout << "Delete at value between :" << obj.DeleteAtValue(4);
//	cout << endl;
//	obj.display();
//	cout << "Delete at value between :" << obj.DeleteAtValue(8);
//	cout << endl;
//	obj.display();
//	cout << "Delete at value between :" << obj.DeleteAtValue(5);
//	cout << endl;
//	obj.display();
//	cout << "Delete at value between :" << obj.DeleteAtValue(6);
//	cout << endl;
//	obj.display();
//	return 0;
//}